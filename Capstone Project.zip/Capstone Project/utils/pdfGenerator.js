function generatePDF(bill, customer) {
    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Set font for Bangla text
        doc.setFont("times", "normal");
        
        // Add header
        doc.setFontSize(20);
        doc.text("বিল রসিদ", 105, 20, { align: "center" });
        
        // Add customer details
        doc.setFontSize(12);
        doc.text(`কাস্টমারের নাম: ${customer.name}`, 20, 40);
        doc.text(`ফোন: ${customer.phone}`, 20, 50);
        if (customer.address) {
            doc.text(`ঠিকানা: ${customer.address}`, 20, 60);
        }
        
        // Add bill details
        doc.text(`বিল নং: ${bill.id}`, 20, 80);
        doc.text(`তারিখ: ${bill.date}`, 20, 90);
        doc.text(`মোট টাকা: ৳${bill.amount}`, 20, 100);
        doc.text(`জমা: ৳${bill.paid}`, 20, 110);
        doc.text(`বাকি: ৳${bill.amount - bill.paid}`, 20, 120);
        
        if (bill.description) {
            doc.text(`বিবরণ:`, 20, 140);
            doc.text(bill.description, 30, 150);
        }
        
        // Save PDF
        doc.save(`bill-${bill.id}.pdf`);
    } catch (error) {
        console.error('PDF generation error:', error);
    }
}
