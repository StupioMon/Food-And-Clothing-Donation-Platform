function App() {
    try {
        const [activeTab, setActiveTab] = React.useState('customers');
        const [customers, setCustomers] = React.useState(() => storage.load('customers') || []);
        const [tasks, setTasks] = React.useState(() => storage.load('tasks') || []);
        const [bills, setBills] = React.useState(() => storage.load('bills') || []);

        React.useEffect(() => {
            storage.save('customers', customers);
        }, [customers]);

        React.useEffect(() => {
            storage.save('tasks', tasks);
        }, [tasks]);

        React.useEffect(() => {
            storage.save('bills', bills);
        }, [bills]);

        const handleAddCustomer = (customer) => {
            const newCustomer = { ...customer, id: Date.now().toString() };
            setCustomers([...customers, newCustomer]);
        };

        const handleAddTask = (task) => {
            const newTask = { ...task, id: Date.now().toString() };
            setTasks([...tasks, newTask]);
        };

        const handleTaskStatusChange = (taskId, status) => {
            setTasks(tasks.map(task => 
                task.id === taskId ? { ...task, status } : task
            ));
        };

        const handleAddBill = (bill) => {
            const newBill = { ...bill, id: Date.now().toString() };
            setBills([...bills, newBill]);
        };

        const handleGeneratePdf = (bill) => {
            const customer = customers.find(c => c.id === bill.customerId);
            if (customer) {
                generatePDF(bill, customer);
            }
        };

        return (
            <div data-name="app" className="min-h-screen bg-gray-50">
                <Navbar activeTab={activeTab} onTabChange={setActiveTab} />
                
                <main className="container mx-auto py-6 px-4">
                    {activeTab === 'customers' && (
                        <div data-name="customers-tab">
                            <CustomerForm onSubmit={handleAddCustomer} />
                            <CustomerList customers={customers} />
                        </div>
                    )}
                    
                    {activeTab === 'tasks' && (
                        <div data-name="tasks-tab">
                            <TaskForm onSubmit={handleAddTask} customers={customers} />
                            <TaskList 
                                tasks={tasks} 
                                customers={customers}
                                onStatusChange={handleTaskStatusChange}
                            />
                        </div>
                    )}
                    
                    {activeTab === 'bills' && (
                        <div data-name="bills-tab">
                            <BillForm onSubmit={handleAddBill} customers={customers} />
                            <BillList 
                                bills={bills} 
                                customers={customers}
                                onGeneratePdf={handleGeneratePdf}
                            />
                        </div>
                    )}
                </main>
            </div>
        );
    } catch (error) {
        console.error('App component error:', error);
        reportError(error);
        return null;
    }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
