function Navbar({ activeTab, onTabChange }) {
    try {
        return (
            <nav data-name="navbar" className="bg-white shadow-md p-4">
                <div className="container mx-auto flex justify-between items-center">
                    <h1 data-name="nav-title" className="text-xl font-bold">কাস্টমার ম্যানেজমেন্ট সিস্টেম</h1>
                    <div className="flex space-x-4">
                        <button 
                            data-name="nav-customers"
                            className={`nav-item ${activeTab === 'customers' ? 'bg-gray-100' : ''}`}
                            onClick={() => onTabChange('customers')}>
                            কাস্টমার
                        </button>
                        <button 
                            data-name="nav-tasks"
                            className={`nav-item ${activeTab === 'tasks' ? 'bg-gray-100' : ''}`}
                            onClick={() => onTabChange('tasks')}>
                            টাস্ক
                        </button>
                        <button 
                            data-name="nav-bills"
                            className={`nav-item ${activeTab === 'bills' ? 'bg-gray-100' : ''}`}
                            onClick={() => onTabChange('bills')}>
                            বিল
                        </button>
                    </div>
                </div>
            </nav>
        );
    } catch (error) {
        console.error('Navbar component error:', error);
        reportError(error);
        return null;
    }
}
