function BillForm({ onSubmit, customers }) {
    try {
        const [formData, setFormData] = React.useState({
            customerId: '',
            amount: '',
            paid: '',
            description: '',
            date: new Date().toISOString().split('T')[0]
        });

        const handleSubmit = (e) => {
            e.preventDefault();
            onSubmit(formData);
            setFormData({
                customerId: '',
                amount: '',
                paid: '',
                description: '',
                date: new Date().toISOString().split('T')[0]
            });
        };

        return (
            <form data-name="bill-form" onSubmit={handleSubmit} className="card">
                <h2 className="text-lg font-semibold mb-4">নতুন বিল যোগ করুন</h2>
                <select
                    data-name="bill-customer"
                    className="form-input"
                    value={formData.customerId}
                    onChange={(e) => setFormData({...formData, customerId: e.target.value})}
                    required
                >
                    <option value="">কাস্টমার বাছাই করুন</option>
                    {customers.map(customer => (
                        <option key={customer.id} value={customer.id}>{customer.name}</option>
                    ))}
                </select>
                <input
                    data-name="bill-amount"
                    type="number"
                    placeholder="মোট টাকা"
                    className="form-input"
                    value={formData.amount}
                    onChange={(e) => setFormData({...formData, amount: e.target.value})}
                    required
                />
                <input
                    data-name="bill-paid"
                    type="number"
                    placeholder="জমা"
                    className="form-input"
                    value={formData.paid}
                    onChange={(e) => setFormData({...formData, paid: e.target.value})}
                    required
                />
                <textarea
                    data-name="bill-description"
                    placeholder="বিবরণ"
                    className="form-input"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                />
                <input
                    data-name="bill-date"
                    type="date"
                    className="form-input"
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                    required
                />
                <button data-name="submit-button" type="submit" className="btn btn-primary">
                    বিল যোগ করুন
                </button>
            </form>
        );
    } catch (error) {
        console.error('BillForm component error:', error);
        reportError(error);
        return null;
    }
}
