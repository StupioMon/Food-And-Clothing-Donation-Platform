function CustomerForm({ onSubmit }) {
    try {
        const [formData, setFormData] = React.useState({
            name: '',
            phone: '',
            address: '',
            email: ''
        });

        const handleSubmit = (e) => {
            e.preventDefault();
            onSubmit(formData);
            setFormData({ name: '', phone: '', address: '', email: '' });
        };

        return (
            <form data-name="customer-form" onSubmit={handleSubmit} className="card">
                <h2 className="text-lg font-semibold mb-4">নতুন কাস্টমার যোগ করুন</h2>
                <input
                    data-name="customer-name"
                    type="text"
                    placeholder="নাম"
                    className="form-input"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                />
                <input
                    data-name="customer-phone"
                    type="tel"
                    placeholder="ফোন নম্বর"
                    className="form-input"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    required
                />
                <textarea
                    data-name="customer-address"
                    placeholder="ঠিকানা"
                    className="form-input"
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                />
                <input
                    data-name="customer-email"
                    type="email"
                    placeholder="ইমেইল"
                    className="form-input"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
                <button data-name="submit-button" type="submit" className="btn btn-primary">
                    সেভ করুন
                </button>
            </form>
        );
    } catch (error) {
        console.error('CustomerForm component error:', error);
        reportError(error);
        return null;
    }
}
