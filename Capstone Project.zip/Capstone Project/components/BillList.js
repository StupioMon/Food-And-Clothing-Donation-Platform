function BillList({ bills, customers, onGeneratePdf }) {
    try {
        const getCustomerName = (customerId) => {
            const customer = customers.find(c => c.id === customerId);
            return customer ? customer.name : 'Unknown';
        };

        return (
            <div data-name="bill-list" className="mt-6">
                <h2 className="text-lg font-semibold mb-4">বিল তালিকা</h2>
                <div className="grid gap-4">
                    {bills.map((bill) => (
                        <div data-name="bill-card" key={bill.id} className="card">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-semibold">{getCustomerName(bill.customerId)}</h3>
                                    <p className="text-gray-600">মোট: ৳{bill.amount}</p>
                                    <p className="text-gray-600">জমা: ৳{bill.paid}</p>
                                    <p className="text-gray-600">বাকি: ৳{bill.amount - bill.paid}</p>
                                    <p className="text-gray-500">তারিখ: {bill.date}</p>
                                    {bill.description && <p className="text-gray-600">বিবরণ: {bill.description}</p>}
                                </div>
                                <button
                                    data-name="generate-pdf"
                                    onClick={() => onGeneratePdf(bill)}
                                    className="btn btn-primary"
                                >
                                    <i className="fas fa-file-pdf mr-2"></i>
                                    PDF
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    } catch (error) {
        console.error('BillList component error:', error);
        reportError(error);
        return null;
    }
}
