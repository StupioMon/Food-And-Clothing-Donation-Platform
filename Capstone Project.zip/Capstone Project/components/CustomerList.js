function CustomerList({ customers }) {
    try {
        return (
            <div data-name="customer-list" className="mt-6">
                <h2 className="text-lg font-semibold mb-4">কাস্টমার তালিকা</h2>
                <div className="grid gap-4">
                    {customers.map((customer) => (
                        <div data-name="customer-card" key={customer.id} className="card">
                            <h3 className="font-semibold">{customer.name}</h3>
                            <p className="text-gray-600">ফোন: {customer.phone}</p>
                            {customer.address && <p className="text-gray-600">ঠিকানা: {customer.address}</p>}
                            {customer.email && <p className="text-gray-600">ইমেইল: {customer.email}</p>}
                        </div>
                    ))}
                </div>
            </div>
        );
    } catch (error) {
        console.error('CustomerList component error:', error);
        reportError(error);
        return null;
    }
}
