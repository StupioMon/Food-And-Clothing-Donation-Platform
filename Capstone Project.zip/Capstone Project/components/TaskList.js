function TaskList({ tasks, customers, onStatusChange }) {
    try {
        const getCustomerName = (customerId) => {
            const customer = customers.find(c => c.id === customerId);
            return customer ? customer.name : 'Unknown';
        };

        return (
            <div data-name="task-list" className="mt-6">
                <h2 className="text-lg font-semibold mb-4">টাস্ক তালিকা</h2>
                <div className="grid gap-4">
                    {tasks.map((task) => (
                        <div data-name="task-card" key={task.id} className="card">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-semibold">{getCustomerName(task.customerId)}</h3>
                                    <p className="text-gray-600">{task.description}</p>
                                    <p className="text-gray-500">তারিখ: {task.dueDate}</p>
                                </div>
                                <select
                                    data-name="task-status"
                                    value={task.status}
                                    onChange={(e) => onStatusChange(task.id, e.target.value)}
                                    className="ml-4 p-2 border rounded"
                                >
                                    <option value="pending">বাকি আছে</option>
                                    <option value="completed">সম্পন্ন</option>
                                </select>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    } catch (error) {
        console.error('TaskList component error:', error);
        reportError(error);
        return null;
    }
}
