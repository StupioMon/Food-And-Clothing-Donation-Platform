function TaskForm({ onSubmit, customers }) {
    try {
        const [formData, setFormData] = React.useState({
            customerId: '',
            description: '',
            dueDate: '',
            status: 'pending'
        });

        const handleSubmit = (e) => {
            e.preventDefault();
            onSubmit(formData);
            setFormData({ customerId: '', description: '', dueDate: '', status: 'pending' });
        };

        return (
            <form data-name="task-form" onSubmit={handleSubmit} className="card">
                <h2 className="text-lg font-semibold mb-4">নতুন টাস্ক যোগ করুন</h2>
                <select
                    data-name="task-customer"
                    className="form-input"
                    value={formData.customerId}
                    onChange={(e) => setFormData({...formData, customerId: e.target.value})}
                    required
                >
                    <option value="">কাস্টমার বাছাই করুন</option>
                    {customers.map(customer => (
                        <option key={customer.id} value={customer.id}>{customer.name}</option>
                    ))}
                </select>
                <textarea
                    data-name="task-description"
                    placeholder="টাস্কের বিবরণ"
                    className="form-input"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    required
                />
                <input
                    data-name="task-due-date"
                    type="date"
                    className="form-input"
                    value={formData.dueDate}
                    onChange={(e) => setFormData({...formData, dueDate: e.target.value})}
                    required
                />
                <button data-name="submit-button" type="submit" className="btn btn-primary">
                    টাস্ক যোগ করুন
                </button>
            </form>
        );
    } catch (error) {
        console.error('TaskForm component error:', error);
        reportError(error);
        return null;
    }
}
